#include <iostream>
#include "complex.h"

int main() {
	
	Complex a(2.0, 1.5);
	std::cout << a << std::endl;

	a += 4.0;
	std::cout << a << std::endl;

	a /= Complex(3.0, 0.1);
	std::cout << a << std::endl;
	Complex b = a;

	std::cout << std::endl;
	
	std::cout << a << std::endl;
	std::cout << b << std::endl;
	std::cout << "a == b: " << (a == b) << std::endl;

	
	b += 0.1;
	std::cout << std::endl;
	std::cout << a << std::endl;
	std::cout << b << std::endl;
	std::cout << "a == b: " << (a == b) << std::endl;

	Complex c(12, 15);
	a += b += c;
	std::cout << std::endl;
	std::cout << "a: " << a << std::endl;
	std::cout << "b: " << b << std::endl;
	std::cout << "c: " << c << std::endl;

	std::cout << std::endl;
	std::cout << "a * 10: " << a * 10 << std::endl;

	std::cout << std::endl;
	std::cout << "10 * a: " << 10 * a << std::endl;

	std::cout << std::endl;
	std::cout << "amp: " << a.amplitude() << "\narg: "<< a.phase() << std::endl;
}