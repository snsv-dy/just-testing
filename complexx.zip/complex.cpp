	#include "complex.h"

Complex::Complex(double re, double im){
	this->re = re;
	this->im = im;
}

Complex::Complex(const Complex &a){
	this->re = a.re;
	this->im = a.im;
}

Complex& Complex::operator+=(const Complex &a){
	this->re += a.re;
	this->im += a.im;
	return *this;
}

Complex& Complex::operator-=(const Complex &a){
	this->re -= a.re;
	this->im -= a.im;
	return *this;
}

Complex& Complex::operator*=(const Complex &a){
	this->re *= a.re;
	this->im *= a.im;
	return *this;
}

Complex& Complex::operator/=(const Complex &a){
	this->re /= a.re;
	this->im /= a.im;
	return *this;
}

Complex operator+(const Complex &a, const Complex &b){
	Complex ret;
	
	ret.re = a.re + b.re;
	ret.im = a.im + b.im;
	
	return ret;
}

Complex operator-(const Complex &a, const Complex &b){
	Complex ret;
	
	ret.re = a.re - b.re;
	ret.im = a.im - b.im;
	
	return ret;
}

Complex operator*(const Complex &a, const Complex &b){
	Complex ret;
	
	ret.re = a.re*b.re - a.im*b.im;
	ret.im = a.im*b.re + a.re*b.im;
	
	return ret;
}

Complex operator/(const Complex &a, const Complex &b){
	Complex ret;
	
	double denom = b.re*b.re - b.im*b.im;
	
	ret.re = a.re*b.re + a.im*b.im;
	ret.re /= denom;
	
	ret.im = a.im*b.re - a.re*b.im;
	ret.im /= denom;
	
	return ret;
}

double Complex::get_re(){
	return this->re;
}

double Complex::get_im(){
	return this->im;
}

double Complex::amplitude(){
	return sqrt(this->re*this->re + this->im * this->im);
}

double Complex::phase(){
	if(this->im == 0)
		return 0.0;
	
	return atan(this->re/this->im);
}

std::ostream& operator<<(std::ostream &o, const Complex &a){
	o << a.re;
	if(a.im < 0){
		o << " - ";
	}else{
		o << " + ";
	}
	o << fabs(a.im) << "i";
	return o;
}

//Complex operator+(const Complex &a, const Complex &b){
//	Complex ret;
//	ret.re = a.re + b.re;
//	ret.im = a.im + b.im;
//
//	return ret;
//}
//
//Complex operator-(const Complex &a, const Complex &b){
//	Complex ret;
//
//	ret.re = a.re - b.re;
//	ret.im = a.im - b.im;
//
//	return ret;
//}
//
//Complex operator*(const Complex &a, const Complex &b){
//	Complex ret;
//
//	ret.re = a.re * b.re;
//	ret.im = a.im * b.im;
//
//	return ret;
//}
//
//Complex operator/(const Complex &a, const Complex &b){
//	Complex ret;
//
//	ret.re = a.re / b.re;
//	ret.im = a.im / b.im;
//
//	return ret;
//}

bool operator==(const Complex &a, const Complex &b){
	return (a.re == b.re) && (a.im == b.im);
}