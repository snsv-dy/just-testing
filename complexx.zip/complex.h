#ifndef _COMPLEX_
#define _COMPLEX_

#include <cmath>
#include <iostream>

class Complex{
public:
	double re, im;

	Complex(double re = 0.0, double im = 0.0);

	Complex(const Complex &a);

	friend Complex operator+(const Complex &a, const Complex &b);
	friend Complex operator-(const Complex &a, const Complex &b);
	friend Complex operator*(const Complex &a, const Complex &b);
	friend Complex operator/(const Complex &a, const Complex &b);
	friend bool operator==(const Complex &a, const Complex &b);
	friend std::ostream& operator<<(std::ostream &o, const Complex &a);

	Complex& operator+=(const Complex &a);
	Complex& operator-=(const Complex &a);
	Complex& operator*=(const Complex &a);
	Complex& operator/=(const Complex &a);
	double get_re();
	double get_im();

	double amplitude();
	double phase();
};

//Complex operator+(const Complex &a, const Complex &b);
//Complex operator-(const Complex &a, const Complex &b);
//Complex operator*(const Complex &a, const Complex &b);
//Complex operator/(const Complex &a, const Complex &b);


#endif